module.exports = {
  //mongoURI: 'mongodb://admin:admin123@ds041228.mlab.com:41228/player-database',
  mongoURI: 'mongodb+srv://MaherBen:MaherBen@cluster0-untz6.mongodb.net/test?retryWrites=true&w=majority',
  secretOrKey: 'theMostSecretPhraseEver123!@#'
};
