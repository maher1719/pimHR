import React, {useState} from "react";


const SingleEmploi = () => {
    const user = useState(state => state.auth.user);


    return (
        <div>

        </div>
    )


};

export default SingleEmploi;